<div>
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400 mb-3">
        
        <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <td class="w-20 p-4">
                    <img src="<?php echo e($article->img); ?>" class="rounded-lg" alt="" srcset="">
                </td>
                <td class="px-6 py-4 font-semibold text-gray-900 dark:text-white">
                    <?php echo e($article->title); ?>

                </td>
                <td class="px-6 py-4">
                    <?php echo e($article->content); ?>

                </td>
                <td class="px-6 py-4">
                    <a href="<?php echo e(route('articles.show',$article->id)); ?>" class="font-medium text-red-600 dark:text-red-500 hover:underline">show</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($articles->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\membership-access\resources\views/livewire/article-dashboard.blade.php ENDPATH**/ ?>