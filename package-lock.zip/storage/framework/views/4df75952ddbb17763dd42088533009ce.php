<div>
    <h2 class="font-semibold text-lg ml-4 mt-3 text-slate-900 dark:text-slate-50">
        Video
    </h2>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 mt-4">
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-12 px-3 lg:mb-2">
            <a target="_blank" href="http://youtube.com/">
                <div class="mb-2 flex justify-center">
                  <span class="text-primary">
                      <img src="<?php echo e($video->thumbnail); ?>" class="h-auto max-w-full rounded-lg" alt="">
                    
                  </span>
                </div>
                <h5 class="mb-3 font-bold text-primary text-slate-900 dark:text-slate-50"><?php echo e($video->title); ?></h5>
                <h6 class="mb-6 font-normal text-slate-700 dark:text-neutral-50"><?php echo e($video->description); ?></h6>
                <?php if(!$loop->last): ?>
                    <div
                    class="absolute right-0 top-0 hidden h-full min-h-[1em] w-px self-stretch border-t-0 bg-gradient-to-tr from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100 lg:block"></div>
                <?php endif; ?>
            </a>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($videos->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\membership-access\resources\views/livewire/video-dashboard.blade.php ENDPATH**/ ?>