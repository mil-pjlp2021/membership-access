<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Role')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-xl sm:rounded-lg">
                <div class="m-4">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-role',['name'=>''])->html();
} elseif ($_instance->childHasBeenRendered('Sz57y43')) {
    $componentId = $_instance->getRenderedChildComponentId('Sz57y43');
    $componentTag = $_instance->getRenderedChildComponentTagName('Sz57y43');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Sz57y43');
} else {
    $response = \Livewire\Livewire::mount('add-role',['name'=>'']);
    $html = $response->html();
    $_instance->logRenderedChild('Sz57y43', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <div class="p-6 lg:p-8 bg-white dark:bg-gray-800 dark:bg-gradient-to-bl dark:from-gray-700/50 dark:via-transparent border-b border-gray-200 dark:border-gray-700">
                    <div class="overflow-hidden">
                        <table class="min-w-full text-left text-sm font-light border-collapse border border-slate-500">
                            <thead class="border-b bg-white font-medium dark:border-neutral-500 dark:bg-neutral-600">
                                <tr>
                                    <th scope="col" class="px-6 border-r dark:border-neutral-500 py-4">#</th>
                                    <th scope="col" class="px-6 border-r dark:border-neutral-500 py-4">Role Name</th>
                                    <th scope="col" class="px-6 border-r dark:border-neutral-500 py-4">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b transition duration-300 ease-in-out hover:bg-neutral-100 dark:border-neutral-500 dark:hover:bg-neutral-600  dark:text-white">
                                    <td class="whitespace-nowrap px-6 border-r dark:border-neutral-500 py-4"><?php echo e($key+1); ?></td>
                                    <td class="whitespace-nowrap px-6 border-r dark:border-neutral-500 py-4"><?php echo e($value->name); ?></td>
                                    <td class="whitespace-nowrap px-6 border-r dark:border-neutral-500 py-4">
                                        <div class="inline-flex">
                                            <div>
                                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-role',['name'=>$value->name])->html();
} elseif ($_instance->childHasBeenRendered('item-'.$value->id.''.time())) {
    $componentId = $_instance->getRenderedChildComponentId('item-'.$value->id.''.time());
    $componentTag = $_instance->getRenderedChildComponentTagName('item-'.$value->id.''.time());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('item-'.$value->id.''.time());
} else {
    $response = \Livewire\Livewire::mount('add-role',['name'=>$value->name]);
    $html = $response->html();
    $_instance->logRenderedChild('item-'.$value->id.''.time(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                            </div>
                                            <div>
                                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('delete-role',['id'=>$value->id])->html();
} elseif ($_instance->childHasBeenRendered('item-'.$value->id.''.time())) {
    $componentId = $_instance->getRenderedChildComponentId('item-'.$value->id.''.time());
    $componentTag = $_instance->getRenderedChildComponentTagName('item-'.$value->id.''.time());
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('item-'.$value->id.''.time());
} else {
    $response = \Livewire\Livewire::mount('delete-role',['id'=>$value->id]);
    $html = $response->html();
    $_instance->logRenderedChild('item-'.$value->id.''.time(), $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\membership-access\resources\views/role.blade.php ENDPATH**/ ?>