<?php return array (
  'add-role' => 'App\\Http\\Livewire\\AddRole',
  'article-dashboard' => 'App\\Http\\Livewire\\ArticleDashboard',
  'delete-role' => 'App\\Http\\Livewire\\DeleteRole',
  'user-role-form' => 'App\\Http\\Livewire\\UserRoleForm',
  'video-dashboard' => 'App\\Http\\Livewire\\VideoDashboard',
);